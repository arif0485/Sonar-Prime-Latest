var initialResData = [
  {
  "INT:CPS": {
    "bugs": {
      "date": "2019-01-01",
      "value": "362"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "8552"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "23.8"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "314"
    }
  }
},
{
  "AETN:SDDA": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "49"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "64.4"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:AESEARCHAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "46"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": null
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "1.9"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:AESEARCHUI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "3"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "330"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "11.1"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:SDCDW": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "20"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "69.3"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:SDLOG": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "100.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:AEXchange-ACKAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:AEXchange-AETNAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:AEXchange-AEXJOBAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:AEXchange-Dashboard": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:AEXchange-DQAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:AEXchange-DQService": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:AEXchange-PUBAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:AEXchange-Publisher": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:AEXchange-Scheduler": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:Benchmark-Webapp": {
    "bugs": {
      "date": "2019-01-01",
      "value": "88"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "1077"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "4.0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:BRDAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "61"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "3758"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "33.1"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "11"
    }
  }
},
{
  "AE:BRDUI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:BRIDGE-IAM": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "520"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "22.8"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "8.0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "ADS:CT": {
    "bugs": {
      "date": "2019-01-01",
      "value": "67"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "163"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "7.7"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "14"
    }
  }
},
{
  "AE:DbaaS-Web-UI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "1"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "809"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "11.2"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:DBaasAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "6"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "627"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "34.6"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "21.8"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:DbaaSAuthAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:DbaaSDbOperations": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:DbaaSDynamoDB": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:DbaaSEC2": {
    "bugs": {
      "date": "2019-01-01",
      "value": "4"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "302"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": null
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "17.2"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:DbaaSRDS": {
    "bugs": {
      "date": "2019-01-01",
      "value": "4"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "490"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": null
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "13.1"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "5"
    }
  }
},
{
  "AE:DBaasWebAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "10"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "137"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.6"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "11.3"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:DEBUT": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "1532"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "9.2"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "333"
    }
  }
},
{
  "AE:GPSAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "63"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "975"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "2.8"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "6.2"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "16"
    }
  }
},
{
  "AE:GPSUI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "777"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "5509"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "19.1"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "9"
    }
  }
},
{
  "AE:IAMAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:IAMUI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:EMAAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "65"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "13797"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "78.7"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "22"
    }
  }
},
{
  "DIS:NCTC": {
    "bugs": {
      "date": "2019-01-01",
      "value": "10"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "372"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "1.5"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "29"
    }
  }
},
{
  "AE:NRAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "SI:PressBox": {
    "bugs": {
      "date": "2019-01-01",
      "value": "25"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "1891"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "2.7"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:RDASH2.5API": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:RDASH2.5UI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "todo": {
    "bugs": {
      "date": "2019-01-01",
      "value": "3"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "234"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": null
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "20.8"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "DB:SCRIBE2": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:SS2API": {
    "bugs": {
      "date": "2019-01-01",
      "value": "2"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "113"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "69.3"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "2.0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:SS2UI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "145"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "1121"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "12.0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "8"
    }
  }
},
{
  "EMA:TEA": {
    "bugs": {
      "date": "2019-01-01",
      "value": "70"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "353"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "7.8"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "8.8"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "Corporate:Hive": {
    "bugs": {
      "date": "2019-01-01",
      "value": "7"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "385"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "4.3"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:TRFMAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "0"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "TVW:JWPlayerIntegration": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "25"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": null
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "TVW:AuthAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "24"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": null
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "TVW:ImageAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "36"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "64.9"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "8.1"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "1"
    }
  }
},
{
  "TVW:ImageSNS": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "4"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "100.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "TVW:MetaDataAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "100"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "73.9"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "3.8"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "TVW:PPASMetadata": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "78"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "75.9"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "TVW:Transcode": {
    "bugs": {
      "date": "2019-01-01",
      "value": "1"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "52"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "34.5"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "5.4"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "TVW:ViewAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "5"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "190"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "40.9"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "4.7"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "TVW:ViewListAPI": {
    "bugs": {
      "date": "2019-01-01",
      "value": "0"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "301"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "86.2"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "28.3"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
},
{
  "AE:VIEW-Web-App": {
    "bugs": {
      "date": "2019-01-01",
      "value": "1"
    },
    "code_smells": {
      "date": "2019-01-01",
      "value": "35"
    },
    "coverage": {
      "date": "2019-01-01",
      "value": "0.0"
    },
    "duplicated_lines_density": {
      "date": "2019-01-01",
      "value": "4.1"
    },
    "vulnerabilities": {
      "date": "2019-01-01",
      "value": "0"
    }
  }
}
]

var projectNameObj = {
  "AETN:SDDA": "AE Data Access",
  "AE:AESEARCHAPI": "AE Search API",
  "AE:AESEARCHUI": "AE Search UI",
  "AE:SDCDW": "AETN Cloud Wrapper",
  "AE:SDLOG": "AETN common Logging",
  "AE:AEXchange-ACKAPI": "AExChange-ACKAPI",
  "AE:AEXchange-AETNAPI": "AExChange-AETNAPI",
  "AE:AEXchange-AEXJOBAPI": "AExChange-AEXJOBAPI",
  "AE:AEXchange-Dashboard": "AExChange-Dashboard",
  "AE:AEXchange-DQAPI": "AExChange-DQAPI",
  "AE:AEXchange-DQService": "AExChange-DQService",
  "AE:AEXchange-PUBAPI": "AExChange-PUBAPI",
  "AE:AEXchange-Publisher": "AExChange-Publisher",
  "AE:AEXchange-Scheduler": "AExChange-Scheduler",
  "AE:Benchmark-Webapp": "Benchmark Webapp",
  "AE:BRDAPI": "Bridge API",
  "AE:BRDUI": "Bridge UI",
  "AE:BRIDGE-IAM": "BRIDGE-IAM",
  "ADS:CT": "Cable Track",
  "INT:CPS": "CPS",
  "AE:DbaaS-Web-UI": "Dbaas Web UI",
  "AE:DBaasAPI": "DBaasAPI",
  "AE:DbaaSAuthAPI": "DbaaSAuthAPI",
  "AE:DbaaSDbOperations": "DbaaSDbOperations",
  "AE:DbaaSDynamoDB": "DbaaSDynamoDB",
  "AE:DbaaSEC2": "DbaaSEC2",
  "AE:DbaaSRDS": "DbaaSRDS",
  "AE:DBaasWebAPI": "DBaasWebAPI",
  "AE:DEBUT": "Debut",
  "AE:GPSAPI": "GPSAPI",
  "AE:GPSUI": "GPSUI",
  "AE:IAMAPI": "IAM API",
  "AE:IAMUI": "IAM UI",
  "AE:EMAAPI": "MFXAPI",
  "DIS:NCTC": "NCTC Portal",
  "AE:NRAPI": "Network Resource API",
  "SI:PressBox": "PressBox",
  "AE:RDASH2.5API": "RDASH 2.5 API",
  "AE:RDASH2.5UI": "RDASH 2.5 UI",
  "todo": "S3arch",
  "DB:SCRIBE2": "SCRIBE2",
  "AE:SS2API": "SS 2 API",
  "AE:SS2UI": "SS 2 UI",
  "EMA:TEA": "TE Analytics",
  "Corporate:Hive": "The Hive",
  "AE:TRFMAPI": "Transformation API",
  "TVW:JWPlayerIntegration": "View AETN.Access.JWPlayerIntegration API",
  "TVW:AuthAPI": "View Auth API",
  "TVW:ImageAPI": "View Image API",
  "TVW:ImageSNS": "View Image SNS",
  "TVW:MetaDataAPI": "View Metadata API",
  "TVW:PPASMetadata": "View PPASMetadata",
  "TVW:Search": "View Search API",
  "TVW:Transcode": "View Transcode API",
  "TVW:ViewAPI": "View ViewAPI API",
  "TVW:ViewListAPI": "View ViewListAPI API",
  "AE:VIEW-Web-App": "View Web App"
}