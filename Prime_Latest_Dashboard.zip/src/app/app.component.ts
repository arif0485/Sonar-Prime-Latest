import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {GoogleChartComponent} from 'angular-google-charts';
import { forkJoin } from 'rxjs';
declare var initialResData;
declare var projectNameObj;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'Code Quality Dashboard';
  projectsCount; bugsCount; vulnerabilitiesCount; codeSmellsCount;
  dupPercent; codePercent;
  datevalue1; minDateValue1; maxDateValue1;
  datevalue2; minDateValue2; maxDateValue2;
  projectNames; projectsSelected; 
  showMax; chartType; chartData1; chartColumnNames1; chartOptions1;
  chartData2; chartColumnNames2; chartOptions2;
  cols; tableData; setcolwidth;
  @ViewChild('mychart') chart: GoogleChartComponent;
  @ViewChild('mychart2') chart2: GoogleChartComponent;
  showGraph1: any;

  @HostListener('window:resize', ['$event'])
    onResize() {
      // let selection = this.chart.wrapper.visualization.getSelection();
      if (this.chart !== undefined) {
        this.chart.dynamicResize;this.chart2.dynamicResize;
        this.chart.ngOnInit(); this.chart2.ngOnInit(); 
     }      
      var grapOuterLayout = document.getElementById('grapOuterLayout');      
      if(window.innerWidth < 1025){
        if(grapOuterLayout.classList.contains("ui-lg-11")){
        grapOuterLayout.classList.remove("ui-lg-11");
        grapOuterLayout.classList.add("ui-lg-12");
        grapOuterLayout.style.marginLeft = "0%";
        }
      }

    }



  constructor(private http: HttpClient){ }

  ngOnInit(){
    this.setcolwidth = true;
    this.projectsCount = "56";
    this.bugsCount = "1050";
    this.vulnerabilitiesCount = '750';
    this.codeSmellsCount = '23 K'
    this.dupPercent = "35";
    this.codePercent = "55";
    this.datevalue1= new Date('2019-01-01');
    this.minDateValue1 = new Date('2019-01-01');
    this.maxDateValue1 = new Date();
    this.datevalue2 = new Date();
    this.minDateValue2 = new Date('2019-01-01');
    this.maxDateValue2 = new Date();
    this.showMax = true;
    // this.showGraph1 = true;
    this.chartType = "LineChart";
    this.chartData1 = [
      [new Date('2019-01-01'), 50, 200,520],  
      [new Date('2019-01-02'),40, 430, 560],  
      [new Date('2019-01-03'), 55, 200, 760],  
      [new Date('2019-01-04'), 50, 290, 400],
      [new Date('2019-01-05'), 50, 200,520],  
      [new Date('2019-01-06'),40, 430, 560],  
      [new Date('2019-01-07'), 55, 200, 700],  
      [new Date('2019-01-08'), 50, 290, 400],
      [new Date('2019-01-09'), 50, 200,520],  
      [new Date('2019-01-10'),40, 430, 560],  
      [new Date('2019-01-11'), 55, 200, 700],  
      [new Date('2019-01-12'), 50, 290, 400]
    ];

    this.chartColumnNames1 = ['Month', 'Bugs','Vulnerabilities', 'Code Smells'];

    this.chartOptions1 = { 
      width: '100%',
      height: '100%',
      animation: {
        duration: 200,
        //startup: true //This is the new option
        easing: 'out'
      },
      hAxis: {
        format: 'MMM dd y',
        gridlines: {color: 'grey'},
        title:'Month',titleTextStyle: {color: '#933'},
        //ticks:[arr[0][0],new Date(2019, 1, 1),new Date(2019, 2, 1),new Date(2019, 3, 1),new Date(2019, 4, 1),new Date(2019, 5, 1),new Date()]
        ticks:[new Date('2019-01-01'),new Date('2019-01-05'),new Date('2019-01-10')]
        },                        
      legend: { position: 'top'},
      chartArea: {
        left: "7%",
        top: "7%",
        height: "80%",
        width: "90%"
      },
      explorer: { 
        actions: ['dragToZoom', 'rightClickToReset'],                      
        keepInBounds: true,
        maxZoomIn: 4.0,
        maxZoomOut: 1.0
      },
    };




    this.chartData2 = [
      [new Date('2019-01-01'), 50, 20],  
      [new Date('2019-01-02'),40, 43],  
      [new Date('2019-01-03'), 55, 20],
      [new Date('2019-01-04'), 50, 25],  
      [new Date('2019-01-05'),40, 30],  
      [new Date('2019-01-06'), 55, 60],
      [new Date('2019-01-07'), 50, 70],  
      [new Date('2019-01-08'),40, 63],  
      [new Date('2019-01-09'), 55, 33],  
      [new Date('2019-01-10'), 50, 20],  
      [new Date('2019-01-11'),40, 30],  
      [new Date('2019-01-12'), 55, 10],  
    ];

    this.chartColumnNames2 = ['Month', 'Code Coverage','Duplications'];

    this.chartOptions2 = { 
      width: '100%',
      height: '100%',
      animation: {
        duration: 200,
        //startup: true //This is the new option
        easing: 'out'
      },
      hAxis: {
        format: 'MMM dd y',
        gridlines: {color: 'grey'},
        title:'Month',titleTextStyle: {color: '#933'},
        //ticks:[arr[0][0],new Date(2019, 1, 1),new Date(2019, 2, 1),new Date(2019, 3, 1),new Date(2019, 4, 1),new Date(2019, 5, 1),new Date()]
        ticks:[new Date('2019-01-01'),new Date('2019-01-05'),new Date('2019-01-10')]
        },                        
      legend: { position: 'top'},
      chartArea: {
        left: "7%",
        top: "7%",
        height: "80%",
        width: "90%"
      },
      explorer: { 
        actions: ['dragToZoom', 'rightClickToReset'],                      
        keepInBounds: true,
        maxZoomIn: 4.0,
        maxZoomOut: 1.0
      },
    };
    
    this.projectNames = [
      { label: 'Bridge', value: 'Bridge' },
      { label: 'Access', value: 'Access' },
      { label: 'Inod', value: 'Inod' },
      { label: 'Dbaas', value: 'Dbaas' },
      { label: 'GPS', value: 'GPS' },
    ];

    this.tableData= [
      {
        title:'Bridge',
        bugs:'75',
        vulnerabilities:'120',
        codeSmells:'523',
        duplications:'23 %',
        codeCoverage:'45 %',
        linesOfCode:'52360'
      },
      {
        title:'Access',
        bugs:'95',
        vulnerabilities:'110',
        codeSmells:'853',
        duplications:'10 %',
        codeCoverage:'75 %',
        linesOfCode:'92560'
      },
      {
        title:'Bridge',
        bugs:'75',
        vulnerabilities:'120',
        codeSmells:'523',
        duplications:'23 %',
        codeCoverage:'45 %',
        linesOfCode:'52360'
      },
      {
        title:'Access',
        bugs:'95',
        vulnerabilities:'110',
        codeSmells:'853',
        duplications:'10 %',
        codeCoverage:'75 %',
        linesOfCode:'92560'
      },
      {
        title:'Bridge',
        bugs:'75',
        vulnerabilities:'120',
        codeSmells:'523',
        duplications:'23 %',
        codeCoverage:'45 %',
        linesOfCode:'52360'
      },
      {
        title:'Access',
        bugs:'95',
        vulnerabilities:'110',
        codeSmells:'853',
        duplications:'10 %',
        codeCoverage:'75 %',
        linesOfCode:'92560'
      },
      {
        title:'Bridge',
        bugs:'75',
        vulnerabilities:'120',
        codeSmells:'523',
        duplications:'23 %',
        codeCoverage:'45 %',
        linesOfCode:'52360'
      },
      {
        title:'Access',
        bugs:'95',
        vulnerabilities:'110',
        codeSmells:'853',
        duplications:'10 %',
        codeCoverage:'75 %',
        linesOfCode:'92560'
      },
      {
        title:'Bridge',
        bugs:'75',
        vulnerabilities:'120',
        codeSmells:'523',
        duplications:'23 %',
        codeCoverage:'45 %',
        linesOfCode:'52360'
      },
      {
        title:'Access',
        bugs:'95',
        vulnerabilities:'110',
        codeSmells:'853',
        duplications:'10 %',
        codeCoverage:'75 %',
        linesOfCode:'92560'
      },
      {
        title:'Bridge',
        bugs:'75',
        vulnerabilities:'120',
        codeSmells:'523',
        duplications:'23 %',
        codeCoverage:'45 %',
        linesOfCode:'52360'
      },
      {
        title:'Access',
        bugs:'95',
        vulnerabilities:'110',
        codeSmells:'853',
        duplications:'10 %',
        codeCoverage:'75 %',
        linesOfCode:'92560'
      },
      {
        title:'Bridge',
        bugs:'75',
        vulnerabilities:'120',
        codeSmells:'523',
        duplications:'23 %',
        codeCoverage:'45 %',
        linesOfCode:'52360'
      },
      {
        title:'Access',
        bugs:'95',
        vulnerabilities:'110',
        codeSmells:'853',
        duplications:'10 %',
        codeCoverage:'75 %',
        linesOfCode:'92560'
      },
      {
        title:'Bridge',
        bugs:'75',
        vulnerabilities:'120',
        codeSmells:'523',
        duplications:'23 %',
        codeCoverage:'45 %',
        linesOfCode:'52360'
      },
      {
        title:'Access',
        bugs:'95',
        vulnerabilities:'110',
        codeSmells:'853',
        duplications:'10 %',
        codeCoverage:'75 %',
        linesOfCode:'92560'
      },
      {
        title:'Bridge',
        bugs:'75',
        vulnerabilities:'120',
        codeSmells:'523',
        duplications:'23 %',
        codeCoverage:'45 %',
        linesOfCode:'52360'
      },
      {
        title:'Access',
        bugs:'95',
        vulnerabilities:'110',
        codeSmells:'853',
        duplications:'10 %',
        codeCoverage:'75 %',
        linesOfCode:'92560'
      },
      {
        title:'Briaadge',
        bugs:'75',
        vulnerabilities:'120',
        codeSmells:'523',
        duplications:'23 %',
        codeCoverage:'45 %',
        linesOfCode:'52360'
      },
      {
        title:'Access',
        bugs:'95',
        vulnerabilities:'110',
        codeSmells:'853',
        duplications:'10 %',
        codeCoverage:'75 %',
        linesOfCode:'92560'
      }
    ];

    this.cols =[            
      { field: 'title', header: 'Project Name' },
      { field: 'bugs', header: 'Bugs' },
      { field: 'vulnerabilities', header: 'Vulnerabilities' },
      { field: 'codeSmells', header: 'Code Smells' },
      { field: 'duplications', header: 'Duplications' },
      { field: 'codeCoverage', header: 'Code Coverage' },
      { field: 'linesOfCode', header: 'Lines of Code' }
    ];

    const urlArray = ['AETN:SDDA', 'AE:AESEARCHAPI', 'AE:AESEARCHUI', 'AE:SDCDW', 'AE:SDLOG', 'AE:AEXchange-ACKAPI', 'AE:AEXchange-AETNAPI', 'AE:AEXchange-AEXJOBAPI', 'AE:AEXchange-Dashboard', 'AE:AEXchange-DQAPI', 'AE:AEXchange-DQService', 'AE:AEXchange-PUBAPI', 'AE:AEXchange-Publisher', 'AE:AEXchange-Scheduler', 'AE:Benchmark-Webapp', 'AE:BRDAPI', 'AE:BRDUI', 'AE:BRIDGE-IAM', 'ADS:CT', 'INT:CPS', 'AE:DbaaS-Web-UI', 'AE:DBaasAPI', 'AE:DbaaSAuthAPI', 'AE:DbaaSDbOperations', 'AE:DbaaSDynamoDB', 'AE:DbaaSEC2', 'AE:DbaaSRDS', 'AE:DBaasWebAPI', 'AE:DEBUT', 'AE:GPSAPI', 'AE:GPSUI', 'AE:IAMAPI', 'AE:IAMUI', 'AE:EMAAPI', 'DIS:NCTC', 'AE:NRAPI', 'SI:PressBox', 'AE:RDASH2.5API', 'AE:RDASH2.5UI', 'todo', 'DB:SCRIBE2', 'AE:SS2API', 'AE:SS2UI', 'EMA:TEA', 'Corporate:Hive', 'AE:TRFMAPI', 'TVW:JWPlayerIntegration', 'TVW:AuthAPI', 'TVW:ImageAPI', 'TVW:ImageSNS', 'TVW:MetaDataAPI', 'TVW:PPASMetadata', 'TVW:Transcode', 'TVW:ViewAPI', 'TVW:ViewListAPI', 'AE:VIEW-Web-App'];
    
    
    this.getSonarData(urlArray).subscribe(
      response => 
      {
        console.log(response[2].measures[0].history)
      }
    )


  }


  getSonarData(apiArray){
    const observableBatch = [];
    apiArray.forEach(( projectKey, ind) => {
      observableBatch.push( this.http.get('http://codequality.aetvn.com/api/measures/search_history?component=' + projectKey + '&metrics=bugs,reliability_rating,vulnerabilities,security_rating,code_smells,sqale_rating') );
    });
    return forkJoin(observableBatch);
  }


  filterData(){

  }


  minimizeGraph() {
    var graphOuterParentLayout = document.getElementById('grapOuterParentLayout');
    var grapOuterLayout = document.getElementById('grapOuterLayout');
    var tableOuterLayout = document.getElementById('tableOuterLayout');
    if(window.innerWidth > 1024){
      graphOuterParentLayout.classList.remove("ui-lg-12");
      grapOuterLayout.classList.remove("ui-lg-11");
      grapOuterLayout.classList.add("ui-lg-12");
      grapOuterLayout.style.marginLeft = "0%";
      tableOuterLayout.classList.remove("ui-lg-12");
      this.showMax = !this.showMax;
    }
    if (this.chart !== undefined) {
      this.chart.dynamicResize;this.chart2.dynamicResize;
      this.chart.ngOnInit(); this.chart2.ngOnInit();
   }


  }

  maximizeGraph() {
    var graphOuterParentLayout = document.getElementById('grapOuterParentLayout');
    var grapOuterLayout = document.getElementById('grapOuterLayout');
    var tableOuterLayout = document.getElementById('tableOuterLayout');
    if(window.innerWidth > 1024){
      graphOuterParentLayout.classList.add("ui-lg-12");
      grapOuterLayout.classList.remove("ui-lg-12");
      grapOuterLayout.classList.add("ui-lg-11");
      grapOuterLayout.style.marginLeft = "5%";
      tableOuterLayout.classList.add("ui-lg-12");
      this.showMax = !this.showMax;
    }
    if (this.chart !== undefined) {
      this.chart.dynamicResize; this.chart2.dynamicResize;
      this.chart.ngOnInit(); this.chart2.ngOnInit();
   }

  }

  graphChange(e){
    if(e.index == 1){
      // this.showGraph1 = ! this.showGraph1;
    }

    if(e.index == 0){
      // this.showGraph1 = ! this.showGraph1;
    }
  }







}
